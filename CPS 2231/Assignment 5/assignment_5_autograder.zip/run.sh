#!/usr/bin/env bash

java -cp classes/:lib/* com.gradescope.Lab5.tests.RunTests












