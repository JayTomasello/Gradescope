package com.gradescope.Lab5.tests;

import org.junit.Test;
import static org.junit.Assert.*;
import com.gradescope.Lab5.Course;
import com.gradescope.Lab5.HybridCourse;
import com.gradescope.Lab5.OnlineCourse;
import com.gradescope.jh61b.grader.GradedTest;
import org.junit.jupiter.BeforeEach;

import java.util.Date;

class Lab5Test {
    Course hybridCourse;
    Course onlineCourse;

    @BeforeEach
    void setUp() {
        hybridCourse = new HybridCourse("Software Engineering", 101, "Dr. Smith", 50);
        onlineCourse = new OnlineCourse("Data Structures", 201, "Prof. Johnson", "Zoom", "http://zoom.us/myclass");
    }

    @Test
    @GradedTest(name="TEST: Creating a Hybrid Course object", max_score=10)
    void testHybridCourseConstructor() {
        HybridCourse course = new HybridCourse("Software Engineering", 101, "Dr. Smith", 50);
        assertNotNull(course);
        assertEquals("Software Engineering", course.getCourseName());
        assertEquals(101, course.getSectionNumber());
        assertEquals("Dr. Smith", course.getInstructorName());
        assertEquals(50, course.getPercentOfRemoteLearning());
    }

    @Test
    @GradedTest(name="TEST: Creating an Online Course object", max_score=10)
    void testOnlineCourseConstructor() {
        OnlineCourse course = new OnlineCourse("Data Structures", 201, "Prof. Johnson", "Zoom", "http://zoom.us/myclass");
        assertNotNull(course);
        assertEquals("Data Structures", course.getCourseName());
        assertEquals(201, course.getSectionNumber());
        assertEquals("Prof. Johnson", course.getInstructorName());
        assertEquals("Zoom", course.getPlatform());
        assertEquals("http://zoom.us/myclass", course.getMeetingLink());
    }

    @Test
    @GradedTest(name="TEST: Course setters and getters", max_score=10)
    void testCourseSettersAndGetters() {
        hybridCourse.setCourseName("Algorithms");
        assertEquals("Algorithms", hybridCourse.getCourseName());

        hybridCourse.setSectionNumber(202);
        assertEquals(202, hybridCourse.getSectionNumber());
        hybridCourse.setInstructorName("Dr. Alan Turing");
        assertEquals("Dr. Alan Turing", hybridCourse.getInstructorName());
    
        hybridCourse.setNumberOfStudentsEnrolled(25);
        assertEquals(25, hybridCourse.getNumberOfStudentsEnrolled());
    }
    
    @Test
    @GradedTest(name="TEST: Hybrid Course capacity", max_score=10)
    void testHybridCourseCapacity() {
        // Assuming getCapacity returns 100 divided by percent of remote learning
        assertEquals(2, hybridCourse.getCapacity());
    }
    
    @Test
    @GradedTest(name="TEST: Online Course capacity", max_score=10)
    void testOnlineCourseCapacity() {
        // Assuming online courses have no real limit on capacity
        assertEquals(Integer.MAX_VALUE, onlineCourse.getCapacity());
    }
    
    @Test
    @GradedTest(name="TEST: Hybrid Course toString() method", max_score=10)
    void testHybridCourseToString() {
        String expected = "HybridCourse{courseName='Software Engineering', sectionNumber=101, instructorName='Dr. Smith', percentOfRemoteLearning=50}";
        assertEquals(expected, hybridCourse.toString());
    }
    
    @Test
    @GradedTest(name="TEST: Online Course toString() method", max_score=10)
    void testOnlineCourseToString() {
        String expected = "OnlineCourse{courseName='Data Structures', sectionNumber=201, instructorName='Prof. Johnson', platform='Zoom', meetingLink='http://zoom.us/myclass'}";
        assertEquals(expected, onlineCourse.toString());
    }
    
    @Test
    @GradedTest(name="TEST: Hybrid Course set percent of remote learning", max_score=10)
    void testHybridCourseSetPercentOfRemoteLearning() {
        ((HybridCourse) hybridCourse).setPercentOfRemoteLearning(70);
        assertEquals(70, ((HybridCourse) hybridCourse).getPercentOfRemoteLearning());
    }
    
    @Test
    @GradedTest(name="TEST: Online Course setter and getter - meeting link", max_score=10)
    void testOnlineCourseSetMeetingLink() {
        ((OnlineCourse) onlineCourse).setMeetingLink("http://newlink.com/myclass");
        assertEquals("http://newlink.com/myclass", ((OnlineCourse) onlineCourse).getMeetingLink());
    }
}

