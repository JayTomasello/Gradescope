package com.gradescope.Lab5;

import java.util.Date;

// Regular class HybridCourse
public class HybridCourse extends Course {
    private int percentOfRemoteLearning;

    public HybridCourse(String courseName, int sectionNumber, String instructorName, int percentOfRemoteLearning) {
        super(courseName, sectionNumber, instructorName);
        this.percentOfRemoteLearning = percentOfRemoteLearning;
    }

    @Override
    public int getCapacity() {
        // Assuming capacity is calculated based on percent of remote learning
        return (int) (100 / percentOfRemoteLearning);
    }

    @Override
    public String toString() {
        return "HybridCourse{" +
                "courseName='" + courseName + '\'' +
                ", sectionNumber=" + sectionNumber +
                ", instructorName='" + instructorName + '\'' +
                ", percentOfRemoteLearning=" + percentOfRemoteLearning +
                '}';
    }

    // Getters and setters
    public int getPercentOfRemoteLearning() {
        return percentOfRemoteLearning;
    }

    public void setPercentOfRemoteLearning(int percentOfRemoteLearning) {
        this.percentOfRemoteLearning = percentOfRemoteLearning;
    }
}
