package com.gradescope.Lab5;

import java.util.Date;

// Regular class OnlineCourse
public class OnlineCourse extends Course {
    private String platform;
    private String meetingLink;

    public OnlineCourse(String courseName, int sectionNumber, String instructorName, String platform, String meetingLink) {
        super(courseName, sectionNumber, instructorName);
        this.platform = platform;
        this.meetingLink = meetingLink;
    }

    @Override
    public int getCapacity() {
        // Assuming the capacity for an online course might be different, adjust accordingly
        return Integer.MAX_VALUE; // Placeholder value indicating no real limit
    }

    @Override
    public String toString() {
        return "OnlineCourse{" +
                "courseName='" + courseName + '\'' +
                ", sectionNumber=" + sectionNumber +
                ", instructorName='" + instructorName + '\'' +
                ", platform='" + platform + '\'' +
                ", meetingLink='" + meetingLink + '\'' +
                '}';
    }

    // Getters and setters
    public String getPlatform() {
        return platform;
    }
    
    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getMeetingLink() {
        return meetingLink;
    }

    public void setMeetingLink(String meetingLink) {
        this.meetingLink = meetingLink;
    }
}
