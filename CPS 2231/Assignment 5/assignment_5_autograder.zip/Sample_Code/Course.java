package com.gradescope.Lab5;

import java.util.Date;

// Abstract class Course
public abstract class Course {
    protected String courseName;
    protected int sectionNumber;
    protected String instructorName;
    protected int numberOfStudentsEnrolled;

    // Constructor without parameters is implicitly defined as public
    public Course() {
    }

    // Constructor with all data fields
    public Course(String courseName, int sectionNumber, String instructorName) {
        this.courseName = courseName;
        this.sectionNumber = sectionNumber;
        this.instructorName = instructorName;
        this.numberOfStudentsEnrolled = 0; // Default value, assuming a new course has no students enrolled yet
    }

    // Abstract method to get the capacity of the course
    public abstract int getCapacity();

    // toString() method is abstract, to be implemented by subclasses
    @Override
    public abstract String toString();

    // Getters and setters
    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getSectionNumber() {
        return sectionNumber;
    }

    public void setSectionNumber(int sectionNumber) {
        this.sectionNumber = sectionNumber;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public int getNumberOfStudentsEnrolled() {
        return numberOfStudentsEnrolled;
    }

    public void setNumberOfStudentsEnrolled(int numberOfStudentsEnrolled) {
        this.numberOfStudentsEnrolled = numberOfStudentsEnrolled;
    }
}