package com.gradescope.Lab6;

public class CodingProblem extends Problem {
    // WRITE YOUR CODE HERE

    // Default constructor
    public CodingProblem() {}

    // Constructor with all fields
    public CodingProblem(int input, String output, String algorithm, String programmingLanguage) {
        // WRITE YOUR CODE HERE
    }

    // Getter and setter for programmingLanguage
    public String getProgrammingLanguage() {
        // WRITE YOUR CODE HERE
    }

    public void setProgrammingLanguage(String programmingLanguage) {
        // WRITE YOUR CODE HERE
    }

    @Override
    public boolean isHard() {
        // WRITE YOUR CODE HERE
    }

    @Override
    public String howToSolve() {
        // WRITE YOUR CODE HERE
    }

    @Override
    public String getFinalAnswer() {
        // WRITE YOUR CODE HERE
    }

    @Override
    public String toString() {
        // WRITE YOUR CODE HERE
    }
}
