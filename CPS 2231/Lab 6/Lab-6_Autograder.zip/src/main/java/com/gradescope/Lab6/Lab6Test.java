package com.gradescope.Computer.tests;

import org.junit.Test;
import static org.junit.Assert.*;
import com.gradescope.Lab6.Solvable;
import com.gradescope.Lab6.CodingProblem;
import com.gradescope.Lab6.Problem;
import com.gradescope.Lab6.MathProblem;
import com.gradescope.jh61b.grader.GradedTest;

import java.util.Date;

public class Lab6Test {

    @Test
    @GradedTest(name="Coding TEST: Default constructor", max_score=1)
    public void testDefaultConstructorCoding() {
        CodingProblem problem = new CodingProblem();
        assertEquals(0, problem.getInput());
        assertNull(problem.getOutput());
        assertNull(problem.getAlgorithm());
        assertNull(problem.getProgrammingLanguage());
    }

    @Test
    @GradedTest(name="Coding TEST: Constructor with ALL fields", max_score=2)
    public void testConstructorWithAllFieldsCoding() {
        CodingProblem problem = new CodingProblem(19, "Output", "Algorithm", "Java");
        assertEquals(19, problem.getInput());
        assertEquals("Output", problem.getOutput());
        assertEquals("Algorithm", problem.getAlgorithm());
        assertEquals("Java", problem.getProgrammingLanguage());
    }

    @Test
    @GradedTest(name="Coding TEST: Setters and getters", max_score=2)
    public void testSettersAndGettersCoding() {
        CodingProblem problem = new CodingProblem();
        problem.setInput(33);
        assertEquals(33, problem.getInput());
        
        problem.setOutput("New Output");
        assertEquals("New Output", problem.getOutput());
        
        problem.setAlgorithm("New Algorithm");
        assertEquals("New Algorithm", problem.getAlgorithm());
        
        problem.setProgrammingLanguage("Python");
        assertEquals("Python", problem.getProgrammingLanguage());
    }

    @Test
    @GradedTest(name="Coding TEST: testIsHard method", max_score=2)
    public void testIsHardCoding() {
        CodingProblem problem = new CodingProblem();
        assertTrue(problem.isHard());
    }

    @Test
    @GradedTest(name="Coding TEST: testHowToSolve method", max_score=2)
    public void testHowToSolveCoding() {
        CodingProblem problem = new CodingProblem(19, "Output", "Algorithm", "Java");
        assertEquals("Write a Java program.", problem.howToSolve());
    }

    @Test
    @GradedTest(name="Coding TEST: testGetFinalAnswer method", max_score=1.5)
    public void testGetFinalAnswerCoding() {
        CodingProblem problem = new CodingProblem();
        assertEquals("Eureka!", problem.getFinalAnswer());
    }

    @Test
    @GradedTest(name="Coding TEST: toString method", max_score=2)
    public void testToStringCoding() {
        CodingProblem problem = new CodingProblem(19, "Output", "Algorithm", "Java");
        String expected = "Input: 19, Output: Output, Algorithm: Algorithm, Programming Language: Java";
        assertEquals(expected, problem.toString());
    }

    @Test
    @GradedTest(name="Math TEST: Default constructor", max_score=1)
    public void testDefaultConstructorMath() {
        MathProblem problem = new MathProblem();
        assertEquals(0, problem.getInput());
        assertNull(problem.getOutput());
        assertNull(problem.getAlgorithm());
        assertEquals(0, problem.getDifficultyLevel());
    }

    @Test
    @GradedTest(name="Math TEST: Constructor with ALL fields", max_score=2)
    public void testConstructorWithAllFieldsMath() {
        MathProblem problem = new MathProblem(10, "100", "Algorithm", 70);
        assertEquals(10, problem.getInput());
        assertEquals("100", problem.getOutput());
        assertEquals("Algorithm", problem.getAlgorithm());
        assertEquals(70, problem.getDifficultyLevel());
    }

    @Test
    @GradedTest(name="Math TEST: Setters and getters", max_score=2)
    public void testSettersAndGettersMath() {
        MathProblem problem = new MathProblem();
        problem.setDifficultyLevel(80);
        assertEquals(80, problem.getDifficultyLevel());
    }

    @Test
    @GradedTest(name="Math TEST: testIsHard method", max_score=2)
    public void testIsHardMath() {
        MathProblem problemEasy = new MathProblem(1, "1", "Algorithm", 30);
        assertFalse(problemEasy.isHard());
        
        MathProblem problemHard = new MathProblem(1, "1", "Algorithm", 70);
        assertTrue(problemHard.isHard());
    }

    @Test
    @GradedTest(name="Math TEST: testHowToSolve method", max_score=2)
    public void testHowToSolveMath() {
        MathProblem problem = new MathProblem();
        assertEquals("Multiply to itself.", problem.howToSolve());
    }

    @Test
    @GradedTest(name="Math TEST: testGetFinalAnswer method", max_score=1.5)
    public void testGetFinalAnsweMath() {
        MathProblem problem = new MathProblem();
        assertEquals("Eureka!", problem.getFinalAnswer());
    }

    @Test
    @GradedTest(name="Math TEST: toString method", max_score=2)
    public void testToStringMath() {
        MathProblem problem = new MathProblem(10, "100", "Algorithm", 70);
        String expected = "Input: 10, Output: 100, Algorithm: Algorithm, Difficulty Level: 70";
        assertEquals(expected, problem.toString());
    }
}
