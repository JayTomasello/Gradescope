package com.gradescope.Lab6;

public class MathProblem extends Problem {
    private int difficultyLevel;

    // Default constructor
    public MathProblem() {}

    // Constructor with all fields
    public MathProblem(int input, String output, String algorithm, int difficultyLevel) {
        super(input, output, algorithm);
        this.difficultyLevel = difficultyLevel;
    }

    // Getter and setter for difficultyLevel
    public int getDifficultyLevel() {
        return difficultyLevel;
    }

    public void setDifficultyLevel(int difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    @Override
    public boolean isHard() {
        return difficultyLevel > 50;
    }

    @Override
    public String howToSolve() {
        return "Multiply to itself.";
    }

    @Override
    public String getFinalAnswer() {
        return "Eureka!";
    }

    @Override
    public String toString() {
        return super.toString() + ", Difficulty Level: " + difficultyLevel;
    }
}
