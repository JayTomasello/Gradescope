package com.gradescope.Lab6;

public class CodingProblem extends Problem {
    private String programmingLanguage;

    // Default constructor
    public CodingProblem() {}

    // Constructor with all fields
    public CodingProblem(int input, String output, String algorithm, String programmingLanguage) {
        super(input, output, algorithm);
        this.programmingLanguage = programmingLanguage;
    }

    // Getter and setter for programmingLanguage
    public String getProgrammingLanguage() {
        return programmingLanguage;
    }

    public void setProgrammingLanguage(String programmingLanguage) {
        this.programmingLanguage = programmingLanguage;
    }

    @Override
    public boolean isHard() {
        return true;
    }

    @Override
    public String howToSolve() {
        return "Write a " + programmingLanguage + " program.";
    }

    @Override
    public String getFinalAnswer() {
        return "Eureka!";
    }

    @Override
    public String toString() {
        return super.toString() + ", Programming Language: " + programmingLanguage;
    }
}
