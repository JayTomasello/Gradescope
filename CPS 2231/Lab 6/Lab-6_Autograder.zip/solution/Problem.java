package com.gradescope.Lab6;

public abstract class Problem implements Solvable {
    private int input;
    private String output;
    private String algorithm;

    // Default constructor
    public Problem() {}

    // Constructor with all fields
    public Problem(int input, String output, String algorithm) {
        this.input = input;
        this.output = output;
        this.algorithm = algorithm;
    }

    // Getters and setters
    public int getInput() {
        return input;
    }

    public void setInput(int input) {
        this.input = input;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    // Abstract method
    public abstract boolean isHard();

    @Override
    public String toString() {
        return "Input: " + input + ", Output: " + output + ", Algorithm: " + algorithm;
    }
}
