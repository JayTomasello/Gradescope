package com.gradescope.Lab6;

public interface Solvable {
    String howToSolve();
    String getFinalAnswer();
}
