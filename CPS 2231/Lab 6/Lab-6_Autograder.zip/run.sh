#!/usr/bin/env bash

java -cp classes/:lib/* com.gradescope.Lab6Test.tests.RunTests












