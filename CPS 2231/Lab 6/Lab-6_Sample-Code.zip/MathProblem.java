package com.gradescope.Lab6;

public class MathProblem extends Problem {
    // WRITE YOUR CODE HERE

    // Default constructor
    public MathProblem() {}

    // Constructor with all fields
    public MathProblem(int input, int output, String algorithm, int difficultyLevel) {
        // WRITE YOUR CODE HERE
    }

    // Getter and setter for difficultyLevel
    public int getDifficultyLevel() {
        // WRITE YOUR CODE HERE
    }

    public void setDifficultyLevel(int difficultyLevel) {
        // WRITE YOUR CODE HERE
    }

    @Override
    public boolean isHard() {
        // WRITE YOUR CODE HERE
    }

    @Override
    public String howToSolve() {
        // WRITE YOUR CODE HERE
    }

    @Override
    public String getFinalAnswer() {
        // WRITE YOUR CODE HERE
    }

    @Override
    public String toString() {
        // WRITE YOUR CODE HERE
    }
}
