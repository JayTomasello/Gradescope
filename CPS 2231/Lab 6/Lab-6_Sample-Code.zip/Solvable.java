package com.gradescope.Lab6;

public interface Solvable {
    // WRITE YOUR CODE HERE
}
