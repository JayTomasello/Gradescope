package com.gradescope.Lab6;

public abstract class Problem implements Solvable {
    // WRITE YOUR CODE HERE

    // Default constructor
    public Problem() {}

    // Constructor with all fields
    public Problem(int input, String output, String algorithm) {
        // WRITE YOUR CODE HERE
    }

    // Getters and setters
    public int getInput() {
        // WRITE YOUR CODE HERE
    }

    public void setInput(int input) {
        // WRITE YOUR CODE HERE
    }

    public String getOutput() {
        // WRITE YOUR CODE HERE
    }

    public void setOutput(String output) {
        // WRITE YOUR CODE HERE
    }

    public String getAlgorithm() {
        // WRITE YOUR CODE HERE
    }

    public void setAlgorithm(String algorithm) {
        // WRITE YOUR CODE HERE
    }

    // Abstract method
    public abstract boolean isHard();

    @Override
    public String toString() {
        // WRITE YOUR CODE HERE
    }
}
